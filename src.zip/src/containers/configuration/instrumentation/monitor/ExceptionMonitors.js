import React from 'react';
import {Tabs, Tab} from 'material-ui/Tabs';

export default class ExceptionMonitors extends React.Component {

  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div>
      <center><h3>Exception monitors feature is coming soon ...</h3></center>
      </div>

    );
  }
}